#pragma once

namespace engine{

	class Level{
	private:
		//platforms vector
		//character
		//point

	public:
		
	};

}