#include <iostream>
#include "Game.hpp"
#include "DEFINITIONS.hpp"

int main(){
    engine::Game(SCREEN_WIDTH,SCREEN_HEIGHT,"Test Game");
}
